const Loading = () => {
  return (
    <div className="container p-5 text-center">
      <h2>LOADING....</h2>
    </div>
  );
};
export default Loading;
